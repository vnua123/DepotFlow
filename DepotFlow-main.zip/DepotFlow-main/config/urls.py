"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
"""
URL configuration for config project.
"""
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path, include
from rest_framework.authtoken.views import obtain_auth_token

from core.views import home

urlpatterns = [
    path('admin/', admin.site.urls),

    path('accounts/login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('accounts/logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

    path('', home, name='home'),

    path('reports/', include('reports.urls')),
    path('depots/', include('depots.urls')),
    path('inventory/', include('inventory.urls')),
    path('operations/', include('operations.urls')),
    path('sales/', include('sales.urls')),
    path('finance/', include('finance.urls')),
    path('rebates/', include('rebates.urls')),
    path('accounts/', include('accounts.urls')),

    path('api/v1/', include('depots.api_urls')),
    path('api/v1/', include('inventory.api_urls')),
    path('api/v1/', include('operations.api_urls')),
    path('api/v1/', include('sales.api_urls')),
    path('api/v1/', include('finance.api_urls')),
    path('api/v1/', include('accounts.api_urls')),
    path('api/v1/auth-token/', obtain_auth_token),

    
]